# TUGAS AKHIR WEB 3

## Anggota Kelompok
* Husni Ramdani 17/416353/SV/14091
* Nama-2 Nim-2
* Nama-3 Nim-3
* Nama-4 Nim-4

## Tentang Tugas Akhir
Website ini tentang Page Portofolio

## Materi Pembelajaran (*REACTJS*):

1.  [**Pengenalan React**](https://reactjs.org/)
2.  [**Step by step guide ReactJs (Official Website)**](https://reactjs.org/docs/hello-world.html)

## Link Materi
Codingan selama pembelajaran bisa diakses [di sini](https://github.com/spindyzel/REACT-WEB-3).

Gunakan npm install gh-pages --save-dev untuk deploy ke github lalu npm run deploy
